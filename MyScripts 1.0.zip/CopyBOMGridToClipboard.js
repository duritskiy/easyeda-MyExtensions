	try
	{
	console.clear()
	var ms=window.MyScripts;


	easyeda.extension.quickScript (); ms.ScriptWindowReSize();





var dlgExportBOM=document.querySelector("#dlgExportBOM > div.panel > div > div > div > div > div.datagrid-view2 > div.datagrid-body > table > tbody")

//var dlgExportBOM=document.getElementById('dlgExportBOM').getElementsByClassName('datagrid-body')[0];;

//var datagrid-body=PanelWindow.getElementsByClassName('datagrid-body')[0];

debugger

	CopyBOMGridToClipboard();


	} 
	catch(e) { alert('Error: ' + e.name + ":" + e.message + "\n" + e.stack);}


	function CopyBOMGridToClipboard()
	{
		
	//var TabIFrame=ms.getTabIFrame(ms.getActiveTab());
	//var a = TabIFrame.contentWindow;
	//debugger;

	var ss=document.getElementsByClassName('menu-item'); 

	var item;
	for(var i=0;i<ss.length;i++)
	{
		
	if(ms.Has(ss[i].attributes,"cmd") && ss[i].attributes.cmd.value=="export_bom" ) 
	{
	item=ss[i];
	//ss[i].click();
	break;
	}
	 
	}

	//console.dir(ss)
	//debugger;
		
	var BOMGrid= $("#BOMGrid").datagrid("getData");


	
	getDataFromServe(BOMGrid);




	//console.log('BOMGrid'); console.dir(BOMGrid); 

	var str="";

	str+="BOM_Manufacturer"+"\t"+ 
	"BOM_Manufacturer Part"+"\t"+
	"BOM_Supplier"+"\t"+
	"BOM_Supplier Part"+"\t"+
	"Footprint"+"\t"+
	"ID"+"\t"+
	"Name"+"\t"+
	"Quantity"+"\t"+
	"uuid"+"\t"+
	"_Price"+"\n";

	for(var i=0;i<BOMGrid.rows.length;i++)
	{

	str+=BOMGrid.rows[i]["BOM_Manufacturer"]+"\t"+ 
	BOMGrid.rows[i]["BOM_Manufacturer Part"]+"\t"+
	BOMGrid.rows[i]["BOM_Supplier"]+"\t"+
	BOMGrid.rows[i]["BOM_Supplier Part"]+"\t"+
	BOMGrid.rows[i]["Footprint"]+"\t"+
	BOMGrid.rows[i]["ID"]+"\t"+
	BOMGrid.rows[i]["Name"]+"\t"+
	BOMGrid.rows[i]["Quantity"]+"\t"+
	BOMGrid.rows[i]["uuid"]+"\t"+
	BOMGrid.rows[i]["_Price"]+"\n";
	}

	ms.copyTextToClipboard(str);

	//console.log('str'); console.log(str); 
	} 


	function getDataFromServe(e) 
	{
		var n = [];
			e.rows.forEach(function (e, t) 
			{
				e["BOM_Supplier Part"] && n.push(e["BOM_Supplier Part"])
			});
			$.getJSON("/api/getPrices" + "?numbers=" + n.join("-")).then(function (t) 
			{

				if (t && t.result.length) 
				{
					e.rows.forEach(function (e) 
					{
						t.result.forEach(function (t) 
						{
							e["BOM_Supplier Part"] == t.lcsc.number && (e._Price = /*("lceda" === Ci ? "?" : "$")*/ + t.lcsc.price)
						})
					});
					
				} 
			})

	}



