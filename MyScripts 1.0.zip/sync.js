try
{
  console.clear()
  var ms = window.MyScripts;

 // easyeda.extension.quickScript(); ms.ScriptWindowReSize();
  ms.zoom_750();

  var json = ms.GetJson();

  if (ms.MySchJson) console.log("schlib", ms.MySchJson.schlib);
  if (ms.MyPcbJson) console.log("FOOTPRINT", ms.MyPcbJson.FOOTPRINT);

  console.log("LastCopiedSchObj", ms.LastCopiedSchObj);
  console.log("LastCopiedPcbObj", ms.LastCopiedPcbObj);

  debugger
  json.head.hasIdFlag=false;
  api('applySource', {source: json, createNew: false}); 

  var json = ms.GetJson();

  ms.json = json;

  //console.log('SelectedIds',SelectedIds)
  //download(JSON.stringify(d1,0,2), 'dvw[1].json', 'text/plain');
}
catch (e) {alert('Error: ' + e.name + ":" + e.message + "\n" + e.stack);}
