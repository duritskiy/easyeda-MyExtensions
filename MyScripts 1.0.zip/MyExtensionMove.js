try
{
console.clear()
var ms=window.MyScripts;


var toolbar=$("#toolbar-common")[0];
var firstChild=toolbar.firstChild;
var lastChild=toolbar.lastChild;
$(lastChild).detach().insertAfter(firstChild);

} 
catch(e) { alert('Error: ' + e.name + ":" + e.message + "\n" + e.stack);}



//easyeda.extension.quickScript(); ms.ScriptWindowReSize();
