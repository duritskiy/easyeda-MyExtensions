// var obj = ms.api('getShape', {id:"gge29044b576c10782f"})
// obj.head.c_para="package`R0603_DURITSKIY_0.9X1.0`BOM_Supplier`LCSC`BOM_Manufacturer`UniOhm`BOM_Manufacturer Part`0603WAF1000T5E`nameAlias`Resistance (Ohms)`BOM_LCSC Assembly`Yes`BOM_Supplier Part`C22775`spicePre`R`spiceSymbolName`0603WAF1000T5E`Package Display`No`BOM_SMT Type`Basic"
// console.clear()
// console.log(obj.head.c_para)
// obj.head.c_para=obj.head.c_para.replace( /\bSMT Type/gm, "BOM_SMT Type" )
// console.log(obj.head.c_para)

if(!MyScripts && window.parent.MyScripts) window.MyScripts=window.parent.MyScripts;
if(window.MyScripts) ms=window.MyScripts;

var json = ms.GetJson();

if (ms.Has(json, "schlib"))
{
    var json_str=JSON.stringify(json, undefined, 2);

    // ms.download(json_str,"1.json")
    json_str=json_str.replace( /\bSMT Type/gm, "BOM_SMT Type" )
    // ms.download(json_str,"2.json")
    ms.api('applySource', {source: JSON.parse(json_str), createNew: false});
}

 