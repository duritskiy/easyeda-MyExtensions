try
{
console.clear()
var ms=window.MyScripts;


 
var a = ms.getTabIFrame(ms.getActiveTab()).contentWindow;
ms.ShowTimeBegin();

var json= ms.GetJson(); console.log("json",json);
ms.json=json;
/////////////////////////////////////////////////////////////////////////////////////




if(ms.Has(json,"FOOTPRINT"))
{
//api('select', {ids:ms.LastCopiedSchIds});

var schlib=ms.MySchJson.schlib
var schlibObj=[];

var FOOTPRINT=ms.MyPcbJson.FOOTPRINT
var FOOTPRINTObj=[];


//console.log(c_paraToJson(schlib.gge164090.head.c_para))

//"package`HDR-1X1/2.54_DURITSKIY`BOM_Supplier`LCSC`BOM_Manufacturer`ReliaPro`BOM_Manufacturer Part`Header-Male-2.54_1x1`BOM_Supplier Part`C81276`Contributor`duritskiy`spicePre`P`Package Display`No`"
//"package`HDR-1X1/2.54`BOM_Supplier``BOM_Manufacturer``BOM_Manufacturer Part``BOM_Supplier Part``spicePre`P`Package Display`No`"

for (var gge in schlib) 
{
	if (!ms.Has(schlib, gge))		continue;
	var obj = ms.GetLibInfo(ms.MySchJson, gge);
	obj.TextObj = GetSchTextObj(obj.LibObj);
	obj.c_paraJson = c_paraToJson(obj.LibObj.head.c_para)
	if (obj.TextObj)schlibObj.push(obj);
}

for (var gge in FOOTPRINT) 
{
	if(!ms.Has(FOOTPRINT,gge))continue;
	var obj=ms.GetLibInfo(ms.MyPcbJson,gge); 
	obj.TextObj=GetPcbTextObj(obj.LibObj);
	
	
	if(obj.TextObj)
	{
	

	FOOTPRINTObj.push( obj); 
		var found=schlibObj.find( (element, index, array) =>  element.pref==obj.pref?1:0 )
		if(!found)continue;
	



if(obj.TextObj.text!=found.TextObj.string)	
{   api('updateShape', {"shapeType": "FOOTPRINT", 
						"jsonCache": 
						{
						"gId": obj.gge, 
						"TEXT": {[obj.TextObj.gId]: {text: found.TextObj.string,pathStr:"",rotation:0 }}
						 }});  

	api('rotate', {ids:[obj.TextObj.gId],degree:-parseFloat(obj.TextObj.rotation)});
}  


	}
}



//debugger

//ms.SmartSelect(json);


/*
//ms.LastCopiedSchObj=[];
ms.LastCopiedSchIds.forEach( function(currentValue, index, array)
{var obj=ms.GetLibInfo(json,array[index]); if(obj.pref)ms.LastCopiedSchObj.push( obj); });

/**/
}


//console.log("LastCopiedIds",LastCopiedIds);
//var obj = api('getShape', {id:LastCopiedIds[LastCopiedIds.length-1]})






//console.log('SelectedIds',SelectedIds)
//download(JSON.stringify(d1,0,2), 'dvw[1].json', 'text/plain');
} 
catch(e) { alert('Error: ' + e.name + ":" + e.message + "\n" + e.stack);}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




function GetSchTextObj(obj){return Object.values(ms.objFilter(obj.annotation,(item)=>item.mark=="L"))[0];}
function GetPcbTextObj(obj){return Object.values(ms.objFilter(obj.TEXT,(item)=>item.type=="L"))[0];}


  function c_paraToJson(e) 
	{

function B(e, t) {
        var n;
        for (var a in t)
            if (v(t, a) && -1 !== e.indexOf(a)) {
                n = !0;
                break
            }
        return n
    }

    function _(e) {
        function t(e) {
            return n[e]
        }
        if ("string" != typeof e)
            return e;
        if (void 0 === e || null === e)
            return "";
        var n = {
            "&#126;": "~",
            "&#94;": "^",
            "&#35;&#64;&#36;": "#@$",
            "&#96;": "`",
            "&apos;": "'",
            "&APOS;": "'"
        };
        return void 0 === e || null === e ? "" : B(e, n) ? (e + "").replace(/(&#96;|&#126;|&#94;|&#35;&#64;&#36;|&apos;)/gi, t) : e
    }

    function v(e, t) {
        return !!e && e.hasOwnProperty(t)
    }

    function E(e) {
        return e ? e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "") : ""
    }
		var ai = "`";
        if (!e)
            return {};
        if ("string" != typeof e)
            return e;
        for (var t = e.split(ai), n = {}, a = 0, r = t.length - 1; a < r; a += 2)
            t[a] && (n[_(t[a])] = _(E(t[a + 1] || "")));
        return n
    }

//easyeda.extension.quickScript(); ms.ScriptWindowReSize();

//console.log('getTabIFrame',TabIFrame);
//console.dir(TabIFrame);
//alert(JSON.stringify(api('getShape', {id:'gge10'}),0,2));
//var shape=a.callCommand.apply(a, ["gJsonCache",[{id:'gge10'}]]);
//var shape=a.callCommand.hooks["gJsonCache"].apply(null, [{id:'gge10'}]);
//var shape=a.callCommand.hooks["gJsonCache"]({id:'gge10'});
//alert(JSON.stringify(shape,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["getJsonCache"]()   ,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["getConfig"]()   ,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["getActiveElement"]('gge8')   ,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["getElementInfoById"]('gge62')   ,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["updateBindId"]('gge62')   ,0,2));
//alert(JSON.stringify(   a.callCommand.hooks["updateJsonCache"]('gge62')   ,0,2));


